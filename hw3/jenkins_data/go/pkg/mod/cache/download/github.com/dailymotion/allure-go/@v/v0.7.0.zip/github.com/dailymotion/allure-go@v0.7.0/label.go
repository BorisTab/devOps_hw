package allure

type label struct {
	Name  string `json:"name,omitempty"`
	Value string `json:"value,omitempty"`
}
