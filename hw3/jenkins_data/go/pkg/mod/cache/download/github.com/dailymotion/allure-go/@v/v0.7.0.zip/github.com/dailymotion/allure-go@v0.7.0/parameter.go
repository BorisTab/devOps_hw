package allure

type parameter struct {
	Name  string `json:"name,omitempty"`
	Value string `json:"value,omitempty"`
}
